$('.slide').slick({
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1
});
