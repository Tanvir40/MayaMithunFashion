<!--Copyright Section-->
    <section id="copyright-section" class="py-3 text-center text-light">
        <div class="container">
          <div class="row">
            <div class="col">
              <p class="lead mb-0">Copyright <?php echo date('Y'); ?> &copy; by <a href="https://softcreation.tech/">Soft Creation Limited</a></p>
            </div>
          </div>
        </div>
    </section>
    <script type="text/javascript">
      $(".paddingHeight").css("min-height", $(window).height()-120);
    </script>
  </body>
</html>